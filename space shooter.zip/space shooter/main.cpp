//programming fundamentals
//#include<iostream>
//#include<graphics.h>
//#include<cstdlib>
//#include<mmsystem.h>
//#include<windows.h>
//    
//using namespace std;
//int playerposx=750,playerposy=800,bulletposx=0,bulletposy=0,i,j=0;
//	int enposx=150,enposy=50;
//	int score=0, crcl=20,lives=3,bullet=2,page=0;
//	char scr[1000],lvs[50],A;
//	bool shoot=false;
//	
//	 
//int gameplay();
//int shooting();
//int main()
//{
//	
//	int  play;
//	cout<<"\npress 1 to play game\n";
//	cin>>play;
//	switch(play)
//	{
//		case 1:
//		{
//			gameplay();
//			break;
//		}		
//	} 
//	
//} 
//inline int shooting()
//{
//	if(shoot==false)
//	{	shoot=true;
//			bulletposx=playerposx;
//			bulletposy=playerposy;
//			bullet=2;
//		
//	
//	}		
//
//}
//inline int gameplay()
//{
//	initwindow(1520,900,(char*)"SPACE SHOOTER");
//	setcolor(RED);
//    settextstyle(8, 0, 7);//TOSELECT STYLE OF TEXT
// 	outtextxy(600,450,(char*)"SPACE SHOOTER");
//    floodfill(185,47,RED);//TO LIMIT COLOR
//    PlaySound(TEXT("start.wav"),NULL,SND_SYNC);
//	
//	cleardevice();
//	setcolor(WHITE);
//
//	while(1)
//	{
//		setactivepage(page);//to handle flickering 
//		setvisualpage(1-page);
//		cleardevice();	
//		readimagefile("BG.jpg",0,0,1520,900);
//		readimagefile("R5.jpg",70,50,1217,850);
//		readimagefile("R2.jpg",playerposx-50,playerposy-50,playerposx+50,playerposy+50);
//		//readimagefile("R3.png",playerposx-50,playerposy-50,playerposx+50,playerposy+50);
//
//		settextstyle(8,0,3);
//		rectangle(70,50,1217,850);
//		line(1250,0,1250,900);
//		outtextxy(1270,200,(char*)"SPACE SHOOTER");
//		outtextxy(1270,500,(char*)"-> for right");
//		outtextxy(1270,600,(char*)"<- for left");
//		outtextxy(1270,700,(char*)"SPACE for fire");
//		outtextxy(300,870,(char*)"press esc key to exit");
//		
//		//for movement
//		if(GetAsyncKeyState(VK_LEFT))
//		{
//			playerposx-=30;	
//			if(playerposx<100)//for boundary
//			{
//					playerposx+=30;
//					
//			}
//		}
//		if(GetAsyncKeyState(VK_RIGHT))
//		{
//			playerposx+=30;	
//			if(playerposx>1180)//for boundary
//			{
//				playerposx-=30 ;
//			}
//		}
//		if(GetAsyncKeyState(VK_UP))
//		{
//			playerposy-=30;	
//			if(playerposy<120)//for boundary
//			{
//					playerposy+=30;
//					
//			}
//		}
//		if(GetAsyncKeyState(VK_DOWN))
//		{
//			playerposy+=30;	
//			if(playerposy>800)//for boundary
//			{
//				playerposy-=30 ;
//			}
//		}
//	
//		readimagefile("en.jpg",enposx-20,enposy-20,enposx+20,enposy+20);
//
//		for( i=0;i<10;i++)
//		{ 
//			//circle(enposx,enposy,crcl);
//			enposy++;
//				if(GetAsyncKeyState(VK_SPACE))	//for shooting
//				{
//					shooting();
//				}
//				if(shoot=true)
//				{
//				 circle(bulletposx,bulletposy,bullet);
//			   	 bulletposy-=5;
//				}
//			
//			if(((bulletposx<=enposx+20)&&(bulletposy<=enposy+20)&&(bulletposx>=enposx)&&(bulletposy>=enposy))||((bulletposx>=enposx-20)&&(bulletposy<=enposy+20)&&(bulletposx<=enposx)&&(bulletposy>=enposy)))
//			{//bullet & enemy collision 
//			 //	crcl=0;
//				bullet=0;
//				score++;
//				enposy=50;
//				enposx=100+rand()%1000;
//			//	crcl=20;
//				bulletposx=0;
//				bulletposy=0;
//				PlaySound(TEXT("fire.wav"),NULL,SND_SYNC);
//
//			}				
//		}	
//		if(bulletposy<50)
//		{
//			shoot=false;
//			bullet=2;
//		}
//	
//		rectangle(1260,270,1450,450);
//		sprintf(scr,"SCORE: %d",score);
//		outtextxy(1270,300,scr);
//		
//	/*
//				readimagefile("en.jpg",enposx-20,enposy-20,enposx+20,enposy+20);
//				readimagefile("R2.jpg",playerposx-50,playerposy-50,playerposx+50,playerposy+50);
//*/
//		if((enposy>825)||((playerposy-50<=enposy+20)&&(playerposx-50<=enposx+80)&&(playerposy-50>enposy)&&(playerposx-50>=enposx))||((playerposy-50<=enposy+20)&&(playerposx-50>=enposx-80)&&(playerposy-50>enposy)&&(playerposx-50<=enposx))||((playerposy+50<=enposy+20)&&(playerposx-50<=enposx+80)&&(playerposy+50>enposy)&&(playerposx-50>=enposx))||((playerposy+50<=enposy+20)&&(playerposx-50<=enposx+80)&&(playerposy+50>enposy)&&(playerposx-50>=enposx)))
//		{j++;//enemy & player collision
//				i=0;
//			enposy=50;
//			enposx=100+rand()%1000;
//			crcl=20;
//			lives--;
//			cout<<"\a";		 	
//
//		
//			
//		}
//		sprintf(lvs,"LIVES: %d",lives);
//		outtextxy(1270,400,lvs);
//		if(j>9)
//		{
//			j=0;
//		}	page=1-page;
//		if(GetAsyncKeyState(VK_ESCAPE)||lives==0)
//		{sprintf(lvs,"LIVES: %d",lives);
//		outtextxy(1270,400,lvs);
//		
//			
//			crcl=0;
//			break;
//		}
//			
//	
//		
//	}
//	setactivepage(page);
//	outtextxy(1270,400,lvs);
//	settextstyle(8,0,7);//TOSELECT STYLE OF TEXT
// 	outtextxy(100,450,(char*)"GAMEOVER PRESS TAB TO EXIT");
// 	PlaySound(TEXT("end.wav"),NULL,SND_SYNC);
// while(1)
// 	if(GetAsyncKeyState(VK_TAB))
//		{
//			closegraph();
//		}
//
//	getch();
//	return 0;
//
//}
//
//Object oriented Programming
#include<iostream>
#include<graphics.h>
#include<cstdlib>
#include<mmsystem.h>
#include<windows.h>

using namespace std;

class Player {//player class
private:
    int posX, posY;
    int bulletPosX, bulletPosY;
    bool shoot;

public:
	Player()
	{
		
	}
    Player(int x, int y) {
        posX = x;
        posY = y;
        bulletPosX = 0;
        bulletPosY = 0;
        shoot = false;
    }
//for movement
    void moveLeft() {
        posX -= 30;
        if (posX < 100)
            posX += 30;
    }

    void moveRight() {
        posX += 30;
        if (posX > 1180)
            posX -= 30;
    }

    void moveUp() {
        posY -= 30;
        if (posY < 120)
            posY += 30;
    }

    void moveDown() {
        posY += 30;
        if (posY > 800)
            posY -= 30;
    }
	
	//bulletshooting

    void shootBullet() {
        if (!shoot) {
            shoot = true;
            bulletPosX = posX;
            bulletPosY = posY;
           
        }
    }

    void updateBulletPosition() {
        if (shoot) {
            bulletPosY -= 40;
            if (bulletPosY < 50) {
                shoot = false;
            }
        }
    }

    int getPosX() {
        return posX;
    }

    int getPosY() {
        return posY;
    }

    int getBulletPosX() {
        return bulletPosX;
    }

    int getBulletPosY() {
        return bulletPosY;
    }

    bool isShooting() {
        return shoot;
    }

    void resetBullet() {
        bulletPosX = 0;
        bulletPosY = 0;
        shoot = false;
    }
};

class Enemy {//Enemy Class
private:
    int posX, posY;

public:

    Enemy() {
        posX = 100 + rand() % 1000;
        posY = 50;
    }

    void move() {
        posY+=20;
        if (posY > 825) {
            posX = 100 + rand() % 1000;
            posY = 50;
        }
    }

    int getPosX() {
        return posX;
    }

    int getPosY() {
        return posY;
    }

    void resetPosition() {
        posX = 100 + rand() % 1000;
        posY = 50;
    }
};

class Game:public Player,public Enemy {//inherited class of Enemy and player to handle game mechanics
private:
    Player player;
    Enemy enemies[10];
    int score;
    int lives;
    int page;

public:
    Game() : player(750, 800) {
        score = 0;
        lives = 3;
        page = 0;
    }

    void start() {
        initwindow(1520, 900, (char*) "SPACE SHOOTER");
		setcolor(RED);
    settextstyle(8, 0, 7);//TOSELECT STYLE OF TEXT
 	outtextxy(600,450,(char*)"SPACE SHOOTER");
    floodfill(185,47,RED);//TO LIMIT COLOR
    PlaySound(TEXT("start.wav"),NULL,SND_SYNC);
	settextstyle(8,0,3);
        while (1) {
            setactivepage(page);
            setvisualpage(1 - page);
            cleardevice();
			setcolor(	WHITE);
            drawBackground();
            drawPlayer();
            drawInstructions();

            handleInput();
            updateGameLogic();

            page = 1 - page;

            if (GetAsyncKeyState(VK_ESCAPE) || lives == 0) {
                break;
            }
        }

        setactivepage(page);
        drawGameOver();

        while (1) {
            if (GetAsyncKeyState(VK_TAB)) {
                closegraph();
                break;
            }
        }
    }

    void drawBackground() {
        readimagefile("BG.jpg", 0, 0, 1520, 900);
        readimagefile("R5.jpg", 70, 50, 1217, 850);
        settextstyle(8, 0, 2);
        rectangle(70, 50, 1217, 850);
        line(1250, 0, 1250, 900);
    }

    void drawPlayer() {
        readimagefile("R2.jpg", player.getPosX() - 50, player.getPosY() - 50, player.getPosX() + 50, player.getPosY() + 50);
    }
//For Ui Design
    void drawInstructions() {
        settextstyle(8, 0, 2);
        outtextxy(1270, 200, (char*) "SPACE SHOOTER");
        outtextxy(1270, 500, (char*) "-> for right");
        outtextxy(1270, 600, (char*) "<- for left");
        outtextxy(1270, 700, (char*) "SPACE for fire");
        outtextxy(300, 870, (char*) "press esc key to exit");
    }
//Input keys
    void handleInput() {
        if (GetAsyncKeyState(VK_LEFT)) {
            player.moveLeft();
        }
        if (GetAsyncKeyState(VK_RIGHT)) {
            player.moveRight();
        }
        if (GetAsyncKeyState(VK_UP)) {
            player.moveUp();
        }
        if (GetAsyncKeyState(VK_DOWN)) {
            player.moveDown();
        }
        if (GetAsyncKeyState(VK_SPACE)) {
            player.shootBullet();
        }
    }

    void updateGameLogic() {
        drawEnemies();
        updateBullet();
        updateCollisions();
        updateScore();
        updateLives();
    }

    void drawEnemies() {
        //for (int i = 0; i < 10; i++) {
		int i=0;
            readimagefile("en.jpg", enemies[i].getPosX() - 20, enemies[i].getPosY() - 20, enemies[i].getPosX() + 20, enemies[i].getPosY() + 20);
            enemies[i].move();
       // }
    }

    void updateBullet() {
        if (player.isShooting()) {
        	 readimagefile("EN.jpg",player.getBulletPosX()-10,player.getBulletPosY()+10,player.getBulletPosX()+10,player.getBulletPosY()-10);
   
         //   circle(, , 2);
            player.updateBulletPosition();
        }
    }
//bullet collsion
    void updateCollisions() {
        for (int i = 0; i < 10; i++) {
            if (((player.getBulletPosX() <= enemies[i].getPosX() + 20) && (player.getBulletPosY() <= enemies[i].getPosY() + 20) &&
                (player.getBulletPosX() >= enemies[i].getPosX()) && (player.getBulletPosY() >= enemies[i].getPosY())) ||
                ((player.getBulletPosX() >= enemies[i].getPosX() - 20) && (player.getBulletPosY() <= enemies[i].getPosY() + 20) &&
                 (player.getBulletPosX() <= enemies[i].getPosX()) && (player.getBulletPosY() >= enemies[i].getPosY()))) {
                score++;
                enemies[i].resetPosition();
                player.resetBullet();
                PlaySound(TEXT("fire.wav"), NULL, SND_SYNC);
            }
//lives collision
            if (((player.getPosY() - 50 <= enemies[i].getPosY() + 20) && (player.getPosX() - 50 <= enemies[i].getPosX() + 80) &&
                 (player.getPosY() - 50 > enemies[i].getPosY()) && (player.getPosX() - 50 >= enemies[i].getPosX())) ||
                ((player.getPosY() - 50 <= enemies[i].getPosY() + 20) && (player.getPosX() + 50 >= enemies[i].getPosX() - 80) &&
                 (player.getPosY() - 50 > enemies[i].getPosY()) && (player.getPosX() + 50 >= enemies[i].getPosX()))) {
                lives--;
                enemies[i].resetPosition();
                PlaySound(TEXT("explode.wav"), NULL, SND_SYNC);
            }
        }
    }

    void updateScore() {
        char strScore[10];
        sprintf(strScore, "%d", score);
        outtextxy(1270, 400, (char*) "Score:");
        outtextxy(1370, 400, strScore);
    }

    void updateLives() {
        char strLives[10];
        sprintf(strLives, "%d", lives);
        outtextxy(1270, 300, (char*) "Lives:");
        outtextxy(1370, 300, strLives);
    }

    void drawGameOver() {
        settextstyle(8, 0, 4);
        outtextxy(500, 300, (char*) "GAME OVER!");
        outtextxy(500, 400, (char*) "Press TAB to exit");
         PlaySound(TEXT("end.wav"),NULL,SND_SYNC);
    }
};

int main()
 {
int str;
	cout<<"\nPlease Enter 1 to start tha Game\n";
	cin>>str;
	if(str==1)
	{
		  Game game;
    	game.start();

	}
	else
	{
		cout<<"\nPlease Try again\n\tand\nenter A valid number";
	}
  
    return 0;
}

